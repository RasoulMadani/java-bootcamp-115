package q03.baseClasses;

import java.time.LocalDate;

public class Goal {
    LocalDate localDate;
    Player player;
}
