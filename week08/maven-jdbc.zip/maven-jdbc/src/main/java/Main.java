import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Connection connection = DatabaseConnection.JDBC_connector();
        User user = new User("allah","allah","allah","allah",connection);
        user.addUserToDatabase();

    }

}
