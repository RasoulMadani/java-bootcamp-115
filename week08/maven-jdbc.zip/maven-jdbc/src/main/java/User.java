import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class User {
    private int id;
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private Connection connection;

    public User(String firstname, String lastname, String username, String password,Connection connection) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.password = password;
        this.connection = connection;
    }

    public int getId() {
        return id;
    }

    public User setId(int id) {
        this.id = id;
        return this;
    }

    public String getFirstname() {
        return firstname;
    }

    public User setFirstname(String firstname) {
        this.firstname = firstname;
        return this;
    }

    public String getLastname() {
        return lastname;
    }

    public User setLastname(String lastname) {
        this.lastname = lastname;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public User setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public User setPassword(String password) {
        this.password = password;
        return this;
    }



    public void addUserToDatabase() throws SQLException {
        String query = "insert into users (firstname,lastname,username,password) values ( ? , ? , ? , ? )";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, this.firstname);
        statement.setString(2, this.lastname);
        statement.setString(3, this.username);
        statement.setString(4, this.password);
        statement.executeUpdate(query);
        System.out.println("inserted ...");
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
