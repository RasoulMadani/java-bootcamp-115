package q01.commonClasses;

public enum EnumRank {
    Lieutenant,
    Sergeant,
    Corporal
}
