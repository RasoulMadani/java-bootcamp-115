1 - select *
    from Artist
    WHERE artist_id IN (
        select A.artist_id
        from Artwork A
        WHERE A.Price > (select AVG(Price) from Artwork)
    );


2 - select COUNT(distinct C.Customer_ID) AS Num_Customers
    from Customer C
    WHERE C.Customer_ID NOT IN (
        select CA.Customer_ID
        from Customer_Art CA
        JOIN Artwork A ON CA.artwork_id = A.artwork_id
        WHERE A.Style = 'style 223'
    );


3 - select A.artist_id, A.Name, COUNT(AG.artwork_id) AS Num_Groups_Participated
    from Artist A
    LEFT JOIN Artwork AG ON A.artist_id = AG.artist_id
    group by A.artist_id, A.Name
    ORDER BY COUNT(AG.artwork_id)
    LIMIT 1;


4 - select *
    from Customer
    WHERE Last_Purchase_Date < DATE_SUB(CURDATE(), INTERVAL 6 MONTH); 


5 - select A.artist_id, A.Name, A.Style, COUNT(A.artwork_id) AS Num_Artworks
    from Artist A
    JOIN Artwork AR ON A.artist_id = AR.artist_id
    WHERE A.Style = 'style 2'
    group by A.artist_id, A.Name, A.Style;


6 - select distinct A.artist_id, A.Name
    from Artist A
    JOIN Artwork AR ON A.artist_id = AR.artist_id
    WHERE AR.Year = '1397';


7 - select A.Title, GROUP_CONCAT(AR.Name) AS Artists
    from Artwork A
    JOIN Artist_AR ON A.artwork_id = AR.artwork_id
    group by A.Title
    HAVING COUNT(*) >= 2;


8 - select C.Customer_ID, C.Name
    from Customer C
    JOIN Customer_Art CA ON C.Customer_ID = CA.Customer_ID
    JOIN Artwork A ON CA.artwork_id = A.artwork_id
    WHERE C.City = 'tehran' AND A.Style = 'style 1';


9 - select A.artist_id, A.Name, AVG(AR.Price) AS Avg_Price
    from Artist A
    JOIN Artwork AR ON A.artist_id = AR.artist_id
    group by A.artist_id, A.Name;


10 - select C.Customer_ID, C.Name, COUNT(CA.artwork_id) AS Num_Artworks
     from Customer C
     JOIN Customer_Art CA ON C.Customer_ID = CA.Customer_ID
     JOIN Artwork A ON CA.artwork_id = A.artwork_id
     JOIN Artwork_Group AG ON A.artwork_id = AG.artwork_id
     JOIN `Group` G ON AG.Group_ID = G.Group_ID
     WHERE G.Name = 'group 12'
     group by C.Customer_ID, C.Name
     ORDER BY COUNT(CA.artwork_id) DESC
     LIMIT 1;
