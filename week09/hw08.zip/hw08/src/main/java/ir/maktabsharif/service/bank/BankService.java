package ir.maktabsharif.service.bank;

import ir.maktabsharif.entity.BaseEntity;

public interface BankService {
    BaseEntity[] getBanks();
}
