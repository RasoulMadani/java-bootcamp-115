package ir.maktabsharif.enums;

public enum TransactionType {
    PAYA,REQULAR,BATCH,SATNA,CARD_WITHDRAW,DEPOSIT_TO_CARD,PAYA_BATCH
}
