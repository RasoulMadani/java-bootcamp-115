package ir.maktabsharif.repository.bank;

import ir.maktabsharif.repository.BaseEntityRespository;

public interface BankRepository extends BaseEntityRespository {
}
