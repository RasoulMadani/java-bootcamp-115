package ir.maktabsharif.util;

public class ApplicationProperties {
        public final static String URL_DB = "jdbc:postgresql://sahand.liara.cloud:33385/hw08";
        public final static String User_Name = "root";
        public final static String PASS = "rZn4MeI7tuET5E5PVWcAluFO";
}
