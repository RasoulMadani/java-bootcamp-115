package ir.maktabsharif.enums;

public enum TransactionStatus {
    DONE,FAILED
}
